from .bitcoinshamir import *
from .BIP39_List import BIP39_List

WordList = BIP39_List()